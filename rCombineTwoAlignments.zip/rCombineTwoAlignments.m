% First Method aligns FI1 with FI2
% Second Method aligns SI1 with SI2
% rCombineTwoAlignments takes an alignment and adds to it correspondences 
%   from another alignment, provided that they do not conflict with what is already aligned

function [C1,C2] = rCombineTwoAlignments(FI1, FI2, SI1, SI2)

m=max(max(FI1),max(SI1));
ToAdd=[];

for i = 1:m
   if ~any(FI1==i)
      b = find(SI1==i);
      if ~isempty(b)
         
         a=find(FI1<i,1,'last');
         if isempty(a) 
            ToAdd=[ToAdd b];
         elseif a == length(FI1) && FI2(a)<SI2(b)
            ToAdd=[ToAdd b];
         elseif FI2(a) < SI2(b) && FI2(a+1) > SI2(b)
            ToAdd=[ToAdd b];
         end 
      end
   end
end
C1=[FI1 SI1(ToAdd)];
C2=[FI2 SI2(ToAdd)];

[S I] = sort(C1);
C1 = S;
C2 = C2(I);